import { Component, OnInit,ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  encapsulation: ViewEncapsulation.None
})
export class LandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
