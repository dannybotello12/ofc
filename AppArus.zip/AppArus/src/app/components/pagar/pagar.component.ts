import { Component, OnInit } from '@angular/core';
import { ConfirmComponent } from '../confirm/confirm.component';
import { DialogService } from "ng2-bootstrap-modal";


@Component({
  selector: 'app-pagar',
  templateUrl: './pagar.component.html'
})
export class PagarComponent implements OnInit {

  constructor(private dialogService:DialogService ) { }

  ngOnInit() {
  }


  showConfirm() {

             console.log("modal");
              let disposable = this.dialogService.addDialog(ConfirmComponent, {
                  title:'Confirm title',
                  message:'Confirm message'})
                  .subscribe((isConfirmed)=>{
                      //We get dialog result
                      if(isConfirmed) {
                          alert('accepted');
                      }
                      else {
                          alert('declined');
                      }
                  });
              //We can close dialog calling disposable.unsubscribe();
              //If dialog was not closed manually close it by timeout
              setTimeout(()=>{
                  disposable.unsubscribe();
              },10000);
          }



}
