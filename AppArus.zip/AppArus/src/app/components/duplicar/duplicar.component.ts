import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-duplicar',
  templateUrl: './duplicar.component.html'
})
export class DuplicarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
